const express = require("express");
const connectDB = require("./src/config/dbconfig");
const UserRoutes = require("./src/users/routes")
const cookieparser = require("cookie-parser")
const session = require("express-session")
const {allowsecure} = require("./src/middleware/allowsecure")
const Mongostore = require ('connect-mongo')(session)



const app = express();
app.use(cookieparser())
app.use(session({
  secret:"mySuperSecretKey",
  resave:false,
  saveUninitialized:true,
  store:new Mongostore({
    url:"mongodb://localhost:27017/User",
    ttl:14*24*60*60,
    autoRemove:"native"
    
  })
}))

app.use(allowsecure)

app.get("/get",(req,res)=>{
res.json({
  msg:"get"
})
})

app.get("/set",(req,res)=>{
if(req.query["key"]){
  res.cookie(req.query["key"],req.query["value"])
}

res.json({
  msg:"set"
})
})

app.use(express.json())
app.use("/user",UserRoutes)



app.listen(3000, () => {
  connectDB();
});