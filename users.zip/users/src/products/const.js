const SIZES = {
    thumbnail:100,
    medium:300,
    large:800
}

module.exports={SIZES}