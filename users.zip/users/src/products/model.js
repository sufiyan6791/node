const mongoose = require("mongoose");   

const GENDERS={
    MALE:1,
    FEMALE:2,
    OTHER:3
}

const UserSchema = new mongoose.Schema({
    username:{
        type:String,
        // required:true
    },
    password:{
        type:String,
        // required:true,
    },
    email:{
        type:String,
        // required:true
    },
    phoneNo:{
        type:Number,
        // required:true,
    },
    gender:{
        type:Number,
       enum:[GENDERS.MALE,GENDERS.FEMALE,GENDERS.OTHER]
    },
    address:{
        type:String,
        // required:true
    },
})
const User = mongoose.model("User",UserSchema);

module.exports = User;