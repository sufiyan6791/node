const Router = require ("express").Router
const user = require ("../users/controllers")
const {requireauth} = require("../middleware/auth")

const routes = Router();

routes.get("/:User_id", user.getone) 
routes.get("/", requireauth ,user.getall)               
routes.post("/", user.createOne)              
routes.put("/:User_id", user.updateone)       
routes.delete("/:User_id", user.deleteOne);   
routes.post("/login", user.login); 
routes.post("/logout", user.logout)
module.exports = routes

module.exports= routes
