const requireauth = (req,res,next)=>{
    console.log(req.session);

    if(req.session.user){
        next();
    }else{
        res.json({msg:"not authenticated"})
    }
    }

    module.exports={requireauth}
    
