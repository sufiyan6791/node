const User = require ("./model")
const mongoose = require("mongoose");

const genOTP = require ("../utils/email")

const sendemail = require("../utils/email")


const getall = async(req,res)=>{
    const user = await User.find()
    res.json({
        data:user
    })
}

const getone = async (req, res) => {
    const userId = req.params["User_id"];

    if (!mongoose.Types.ObjectId.isValid(userId)) {
        return res.status(400).json({ error: "Invalid user ID" });
    }

    try {
        const userone = await User.findOne({ _id: userId });

        if (!userone) {
            return res.status(404).json({ error: "User not found" });
        }

        return res.json({
            data: userone
        });
    } catch (err) {
        console.log(err);

        return res.status(500).json({ error: "Server error" });
    }
}


const createOne = async (req, res) => {
    const bodyData = req.body;

    if (!bodyData.username) {
        return res.status(400).json({ error: 'Name is required' });
    }
    if (!bodyData.email) {
        return res.status(400).json({ error: 'Email is required' });
    }
    if (!bodyData.password) {
        return res.status(400).json({ error: 'Password is required' });
    } if (!bodyData.address) {
        return res.status(400).json({ error: 'address is required' });
    } if (!bodyData.gender) {
        return res.status(400).json({ error: 'Gender is required' });
    }

    try {
        const createdUser = await  User.create({
            username: bodyData.username,
            email: bodyData.email,
            password: bodyData.password,
            address: bodyData.address,
            gender: bodyData.gender,
        });

        return res.json({
            msg: "User created successfully",
            data: createdUser
        });
    } catch (error) {
        console.log(error);

        return res.status(500).json({ error: 'An error occurred while creating the user.' });
    }
}

const updateone = async (req, res) => {
    const userId = req.params["User_id"]
    const bodyData = req.body

    if (!mongoose.Types.ObjectId.isValid(userId)) {
        return res.status(400).json({
            error: "Invalid userId, Please provide valid mongoDB objectId"
        })
    }

    if (!bodyData || Object.keys(bodyData).length === 0) {
        return res.status(400).json({
            error: "no data provie to update"
        })
    }

    try {
        const user = await User.findById(userId)

        if (!user) {
            return res.status(404).json({
                error: "user not found"
            })
        }

        const updatedUser = await usermodel.findByIdAndUpdate(userId, bodyData, { new: true })

        return res.json({
            msg: "User updated successfully",
            data: updatedUser
        })

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            error: "an error when upadatin user",
            details: error.message
        })
    }

}




const deleteOne = async (req, res) => {
    const userId = req.params["User_id"];

    if (!mongoose.Types.ObjectId.isValid(userId)) {
        return res.status(400).json({
            error: 'Invalid user ID format.'
        });
}

    try {
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({
                error: 'User not found.'
            });
        }

        await user.deleteOne();

        return res.json({
            msg: 'User deleted successfully.'
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            error: 'An error occurred while deleting the user.',
            details: error.message
        });
    }
};

const login = async (req,res)=>{
        let {email,password}=req.body;

        if(!email && !password){
            return res.status(400).json({
                error:"email and pass are required "
            })
        }

    try{
        const user =  await User.findOne({email})

if(!user){
    return res.status(404).json({
        error:"user not found"
    })
}

        if(user.password !== password){
            return res.status(401).json({
                error:"invalid password"
            })
        }

       req.session.user={
        username:user.username
       }

    return res.json({
        msg:"login succesfull",
        user:{
            id:user._id,
            username:user.username,
            email:user.email,
            address:user.address
        }
    })
    } catch (error){
        console.log(error);
        return res.status(500).json({
            error:"an error accured during login",
            details:error.message
        })
        
    }
    }

    const logout = (req,res)=>{
        req.session.destroy()

        res.json({msg:"logout success"})
    }


    const sendOTP = async (req,res)=>{
        const {email,username}=req.body

        const user =await  User.findOne({email:email})

        if(!user) return res.json({msg:"user not found"})
        const otp = genOTP()
        
        const msg = OTP_EMAIL.html1 + OTP +OTP_EMAIL.html2

        await sendEmail(email,OTP_EMAIL.subject,msg)

        OTP_store[email]= {OTP:OTP, time:(Date.now() + 90000)}
        return res.json ({msg:"OTP SEND"})
    }


module.exports={getall,getone,createOne,updateone,deleteOne,login,logout}
