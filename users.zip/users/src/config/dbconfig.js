const mongoose = require("mongoose");

const connectDB = async()=>{
    const connection = await mongoose.connect("mongodb://localhost:27017/User",{
        autoIndex:false
    })

    if (connection){
        console.log("mongo Db has connected");  
    }else{
        console.log("error connecting mongodb");
        
    }
}

module.exports = connectDB 