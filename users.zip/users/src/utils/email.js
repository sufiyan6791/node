const transporter = require ("../config/emailconfig")

const sendemail = async (receiver,subject,msg)=>{
    const emailoption={
        from:process.env.EMAIL_USER,
        to:receiver,
        subject:subject,
        html:msg
    }
    await transporter.sendemail(emailoption)
}





const genOTP=(size=4)=>{
    let OTP=""

    for(let i=1; i<=size; i++){
        OPT += Math.floor(Math.random()*10)
    }

    return OTP
}

module.export={sendemail,genOTP}